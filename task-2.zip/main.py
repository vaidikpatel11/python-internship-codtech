
class StudentGradeTracker:
    def __init__(self):
        self.grades = {}

    def add_grade(self, subject, grade):
        """Add a grade for a subject"""
        if subject in self.grades:
            self.grades[subject].append(grade)
        else:
            self.grades[subject] = [grade]

    def calculate_average(self, subject):
        """Calculate the average grade for a subject"""
        if subject in self.grades:
            grades = self.grades[subject]
            return sum(grades) / len(grades)
        else:
            return None

    def calculate_overall_average(self):
        """Calculate the overall average grade"""
        total_grades = []
        for grades in self.grades.values():
            total_grades.extend(grades)
        return sum(total_grades) / len(total_grades)

    def get_letter_grade(self, grade):
        """Convert a grade to a letter grade"""
        if grade >= 90:
            return "A"
        elif grade >= 80:
            return "B"
        elif grade >= 70:
            return "C"
        elif grade >= 60:
            return "D"
        else:
            return "F"

    def display_grades(self):
        """Display all grades"""
        for subject, grades in self.grades.items():
            average = self.calculate_average(subject)
            print(f"Subject: {subject}")
            print(f"Grades: {grades}")
            print(f"Average: {average:.2f} ({self.get_letter_grade(average)})")
            print()

    def display_overall_grade(self):
        """Display the overall grade"""
        overall_average = self.calculate_overall_average()
        print(f"Overall Average: {overall_average:.2f} ({self.get_letter_grade(overall_average)})")

def main():
    tracker = StudentGradeTracker()

    while True:
        print("Student Grade Tracker")
        print("1. Add Grade")
        print("2. Display Grades")
        print("3. Display Overall Grade")
        print("4. Quit")

        choice = input("Choose an option: ")

        if choice == "1":
            subject = input("Enter subject: ")
            grade = float(input("Enter grade: "))
            tracker.add_grade(subject, grade)
        elif choice == "2":
            tracker.display_grades()
        elif choice == "3":
            tracker.display_overall_grade()
        elif choice == "4":
            break
        else:
            print("Invalid choice. Please choose again.")

if __name__ == "__main__":
    main()
